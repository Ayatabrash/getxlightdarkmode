import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getxlightdarkmode/controller/theme_controllers.dart';
import 'package:getxlightdarkmode/pages/homePage.dart';

void main() {
  Get.put(ThemeController()); // إنشاء ال ThemeController
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
      theme: Get.find<ThemeController>().themeData.value,
    );
  }
}
